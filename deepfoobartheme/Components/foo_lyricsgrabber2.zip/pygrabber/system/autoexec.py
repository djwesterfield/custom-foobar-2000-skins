if __name__ == "__main__":
    import socket
    # Default Timeout
    socket.setdefaulttimeout(15)
